package TM_AddEmployee;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class loginPage extends ProjectSpecificMethods{
	
	public loginPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public loginPage signin() throws InterruptedException {
		driver.findElement(By.xpath("(//a[contains(text(),'Sign in')])[2]")).click();
		driver.findElement(By.id("Microsoft")).click();

		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("vigneshr.iopex@appsheetdemo.com");
		
		locateElement("id", "idSIButton9").click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@name='passwd']")).sendKeys("selenium@123a");
		
		Thread.sleep(2000);
		locateElement("id", "idSIButton9").click();
		Thread.sleep(1000);
		locateElement("id", "idBtn_Back").click();
		//driver.findElement(By.xpath("(//span[@class='VfPpkd-vQzf8d'])[2]")).click();
	   // driver.findElement(By.linkText("Next")).click();
		//Thread.sleep(2000);
		//driver.findElement(By.xpath("//span[contains(text(),\"Allow\")]")).click();
		
		Thread.sleep(2000);
		try{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(By.xpath("//p[contains(text(),\"IR - testing - 10th August\")]")).click();
		
		switchToWindow("IR - testing - 10th August - AppSheet");
		WebElement e = driver.findElement(By.linkText("IR - testing - 10th August - AppSheet"));
		shootWebElement(e);
		/*locateElement("link","open_in_new").click();
		Thread.sleep(2000);
		switchToWindow("TM testing - 10 Jun");
		
		locateElement("xpath","//span[text()=\"Ok\"]").click();*/
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return this;
	}

}
