package TM_AddEmployee;

import java.time.Duration;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.pages.ViewLeadPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class AddEmployee extends ProjectSpecificMethods{


	public AddEmployee(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public AddEmployee tapStaff() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		//switchToFrame("SimulatorIFrame");
		driver.findElement(By.xpath("(//span[contains(text(),\"Staff\")])[3]")).click();
		return this;
	}
	
	public AddEmployee clickAdd() {
		driver.findElement(By.xpath("(//span[contains(text(),\"Staff\")])[3]")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		locateElement("xpath", "//button[@data-testid=\"overlay-actions-fab\"]").click();	
		return this;
	}
	
	public AddEmployee fullName(int id) {
		
		locateElement("xpath", "(//input[@data-testid=\"text-type-input\"])[2]").sendKeys("Staff"+id);
		try {
			Thread.sleep(1000);
			System.out.println("Staff"+id);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AddEmployee phoneNumber() {
		locateElement("xpath", "//input[@type=\"tel\"]").sendKeys("1234567890");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AddEmployee email(int id) {
		locateElement("xpath", "//input[@type=\"email\"]").sendKeys("Staff"+id+"@gmail.com");
		try {
			Thread.sleep(1000);
			System.out.println("Staff"+id+"@gmail.com");
			reportStep("Inputs", "PASS");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AddEmployee permission(String permission) {
		locateElement("id", "__TableEntryScreenEMPLOYEE_DETAILS_SchemaEmployee_details_based_on_AvailabilityEMP_ROLE").click();
		
		try {
			Thread.sleep(1000);
			locateElement("xpath", "//span[contains(text(),'"+permission+"')]").click();
			reportStep("Role is selected", "PASS");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AddEmployee role(String role) {
		locateElement("xpath", "(//div[@class=\"BaseTypeDisplay ListSelect--empty-spacer\"])[2]").click();
		
		try {
			Thread.sleep(1000);
			locateElement("xpath", "//span[contains(text(),'"+role+"')]").click();
			reportStep("Role is selected", "PASS");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AddEmployee save() {
		
		try {
			Thread.sleep(1000);
			locateElement("xpath","(//span[@role=\"button\" or text()=\"Save\"])[5]").click();
			Thread.sleep(2000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AddEmployee verify() {
		
		String formtitle = locateElement("xpath", "//span[@class=\"app_title\"]").getText();
		try {
		if (formtitle.equalsIgnoreCase("Staff"))
		{
			Thread.sleep(1000);
			locateElement("xpath", "//button[@id=\"AppHeader__sync\"]").click();
			Thread.sleep(5000);
			locateElement("xpath", "(//div[@class=\"DeckView__list\"])[4]").click();
			locateElement("xpath", "//button[@id=\"AppHeader__back\"]").click();
			Thread.sleep(1000);
			//String empid = "_Staff"+id+"_gmail_com";
			//System.out.println(empid);
			//WebElement Ele = locateElement("xpath", "//div[@id=\"draggable_RowElement_Employee details based on Availability"+empid+"\"]");
			//Ele.click();
			//Actions actions = new Actions(driver);
			//actions.keyDown(empid);
			Thread.sleep(2000);
			//actions.perform();
			//js.executeScript("arguments[0].scrollIntoView();", Ele);
			//Ele.click();
			reportStep("Staff is created", "PASS");
			
			// List view
			locateElement("xpath", "//button[@id=\"AppHeader__back\"]").click();
			Thread.sleep(2000);
			reportStep("List view", "PASS");
		}
		else {
			System.out.println("Failed");
			driver.quit();
		}
		}
		catch(InterruptedException e){
			System.out.println("Failed");
			driver.quit();
		}
			
		return this;
	}
	
	
	
	
	
}

