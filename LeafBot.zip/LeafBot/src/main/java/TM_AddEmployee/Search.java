package TM_AddEmployee;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class Search extends ProjectSpecificMethods{


	public Search (RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}

	public Search verify(int id) {

		String formtitle = locateElement("xpath", "//span[@class=\"app_title\"]").getText();
		try {
			if (formtitle.equalsIgnoreCase("Staff"))
			{
				Thread.sleep(1000);
				locateElement("xpath", "//button[@id=\"AppHeader__sync\"]").click();
				Thread.sleep(5000);
				//locateElement("xpath", "((//div[@class=\"DeckView__list\"])[4])//following-sibling::span").click();
				//locateElement("xpath", "//button[@id=\"AppHeader__back\"]").click();
				//Thread.sleep(1000);
				String empid = "_Staff"+id+"_gmail_com";
				System.out.println(empid);
				try {
					driver.findElement(By.id("DeckPage10c33e")).click();
					Thread.sleep(1000);
					WebElement Ele = locateElement("id", "Deck_RowElement_Employee_details_based_on_Availability"+empid+"");
					Ele.click();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				//Actions actions = new Actions(driver);
				//actions.keyDown(empid);
				Thread.sleep(2000);
				//actions.perform();
				//js.executeScript("arguments[0].scrollIntoView();", Ele);
				//Ele.click();
				reportStep("Staff is created", "PASS");

				// List view
				locateElement("xpath", "//button[@id=\"AppHeader__back\"]").click();
				Thread.sleep(2000);
				reportStep("List view", "PASS");
			}
			else {
				System.out.println("Failed");
				driver.quit();
			}
		}
		catch(InterruptedException e){
			System.out.println("Failed");
			driver.quit();
		}

		return this;
	}

	public Search pointstaff() {
		String formtitle = locateElement("xpath", "//span[@class=\"app_title\"]").getText();
		try {
			if (formtitle.equalsIgnoreCase("Staff"))
			{
				Thread.sleep(3000);
				//String empid = ("Staff"+id);
				//System.out.println(empid);
				//locateElement("link","Unavailable");
				//	WebElement Ele = locateElement("link", "Unavailable");
				//Detail view of profile
				String sam = "_dilip_natarajan_iopex_com";
				WebElement Ele = locateElement("xpath", "//div[@id=\"draggable_RowElement_Employee details based on Availability"+sam+"\"]");
				Ele.click();
				Thread.sleep(2000);
				reportStep("Detail view", "PASS");

				// List view of profile
				locateElement("xpath", "//button[@id=\"AppHeader__back\"]").click();
				Thread.sleep(2000);
				reportStep("List view", "PASS");
				//js.executeScript("arguments[0].scrollIntoView();", Ele);
				//Ele.click();
			}
			else {
				System.out.println("Failed");
				driver.quit();
			}
		}
		catch(InterruptedException e){
			System.out.println("Failed");
			driver.quit();
		}

		return this;
	}

}
