package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

import TM_AddEmployee.loginPage;

public class IR_sample extends ProjectSpecificMethods {
	@BeforeTest
	public void setValues() {
		testCaseName = "IRsample";
		testDescription = "test";
		nodes = "Leads";
		authors = "Vignesh";
		category = "Smoke";
		dataSheetName = "Dummy data";
	}
	@Test()
	public void Sample() throws InterruptedException {
		new loginPage(driver, node)
		.signin();
	}
}
