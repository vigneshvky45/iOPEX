package testcases;

import java.util.Random;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import TM_AddEmployee.AddEmployee;
import TM_AddEmployee.Search;
import TM_AddEmployee.loginPage;

public class TC_Addemployee1 extends ProjectSpecificMethods{
	Random random = new Random();
	int id = random.nextInt(1000);

	@BeforeTest
	public void setValues() {
		testCaseName = "Add employee";
		testDescription = "test";
		nodes = "Leads";
		authors = "Vignesh";
		category = "Smoke";
		dataSheetName = "TC001";
	}

	@Test()
	public void SmAddEmployee() throws InterruptedException {
		new loginPage(driver, node)
		.signin();
		new AddEmployee(driver, node)
		.tapStaff()
		.clickAdd()
		.fullName(id)
		.phoneNumber()
		.email(id)
		.permission("Staff")
		.role("Cashier")
		.save();
		new Search(driver, node)
		.verify(id);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
